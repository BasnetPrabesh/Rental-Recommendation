# rental_backend/items/utils.py

import math
import re
import time
from collections import Counter

import numpy as np
import requests


# ──────────────────────────────────────────────────────────────────
# Haversine distance
# ──────────────────────────────────────────────────────────────────

def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Calculate the distance between two GPS points on Earth's surface.
    Returns distance in kilometers.
    """
    R = 6371.0

    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)

    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad

    a = (math.sin(dlat / 2) ** 2 +
         math.cos(lat1_rad) * math.cos(lat2_rad) *
         math.sin(dlon / 2) ** 2)

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return R * c


def bounding_box(lat, lon, radius_km):
    """
    Given a center point and a radius in km, returns an approximate
    (min_lat, max_lat, min_lon, max_lon) box that fully contains the
    circle of that radius — used as a cheap DB-level pre-filter before
    running the exact Haversine formula.
    """
    lat_delta = radius_km / 111.0
    cos_lat = max(math.cos(math.radians(lat)), 0.01)
    lon_delta = radius_km / (111.0 * cos_lat)

    return (
        lat - lat_delta, lat + lat_delta,
        lon - lon_delta, lon + lon_delta,
    )


# ──────────────────────────────────────────────────────────────────
# Geocoding — with a simple in-memory cache + rate limiting
# ──────────────────────────────────────────────────────────────────

_geocode_cache = {}
_last_geocode_call = 0.0
_MIN_GEOCODE_INTERVAL = 1.0


def geocode_location(location_text):
    """
    Convert a text address into (latitude, longitude) using Nominatim.
    Cached by normalized query text; rate-limited to respect Nominatim's
    ~1 request/second usage policy.
    """
    global _last_geocode_call

    cache_key = location_text.strip().lower()
    if cache_key in _geocode_cache:
        return _geocode_cache[cache_key]

    elapsed = time.monotonic() - _last_geocode_call
    if elapsed < _MIN_GEOCODE_INTERVAL:
        time.sleep(_MIN_GEOCODE_INTERVAL - elapsed)

    url = "https://nominatim.openstreetmap.org/search"
    search_query = f"{location_text}, Kathmandu, Nepal"
    params = {
        "q": search_query,
        "format": "json",
        "limit": 1,
        "countrycodes": "np",
    }
    headers = {"User-Agent": "RoomFinderApp/1.0"}

    try:
        _last_geocode_call = time.monotonic()
        response = requests.get(url, params=params, headers=headers, timeout=5)
        response.raise_for_status()
        results = response.json()

        if results:
            lat = float(results[0]["lat"])
            lon = float(results[0]["lon"])
            _geocode_cache[cache_key] = (lat, lon)
            return lat, lon
        else:
            _geocode_cache[cache_key] = (None, None)
            return None, None

    except requests.RequestException as e:
        print(f"Geocoding failed: {e}")
        return None, None


# ──────────────────────────────────────────────────────────────────
# Tokenizing
# ──────────────────────────────────────────────────────────────────

STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "in", "on", "at",
    "to", "for", "of", "and", "or", "with", "this", "that", "it",
    "as", "by", "from", "be", "been", "being",
}


def tokenize(text, strip_stopwords=True):
    """
    Breaks text into lowercase words, stripping punctuation. Numbers
    stay attached to adjacent letters (e.g. "2bhk" stays whole).
    """
    text = text.lower()
    tokens = re.findall(r"[a-z0-9]+", text)
    if strip_stopwords:
        tokens = [t for t in tokens if t not in STOPWORDS]
    return tokens


# ──────────────────────────────────────────────────────────────────
# TF-IDF + Cosine Similarity
# Formulas hand-written; numpy used only for array arithmetic.
# ──────────────────────────────────────────────────────────────────

def build_vocabulary(tokenized_documents):
    """
    Collects every unique word across all documents into a fixed,
    sorted list (the vocabulary), and a lookup from word -> its index.
    """
    vocab = sorted({word for tokens in tokenized_documents for word in tokens})
    word_index = {word: i for i, word in enumerate(vocab)}
    return vocab, word_index


def compute_idf_vector(tokenized_documents, vocab, word_index):
    """
    Inverse Document Frequency, one value per vocabulary word.
    Smoothed IDF: log((n_docs+1)/(df+1)) + 1.
    """
    n_docs = len(tokenized_documents)
    df = np.zeros(len(vocab))
    for tokens in tokenized_documents:
        for word in set(tokens):
            df[word_index[word]] += 1
    return np.log((n_docs + 1) / (df + 1)) + 1


def document_to_tfidf_vector(tokens, vocab, word_index, idf):
    """
    Builds one document's TF-IDF vector: tf = count / total_words,
    vec[word's index] = tf * idf.
    """
    vec = np.zeros(len(vocab))
    if not tokens:
        return vec
    counts = Counter(tokens)
    total = len(tokens)
    for word, count in counts.items():
        idx = word_index.get(word)
        if idx is not None:
            vec[idx] = (count / total) * idf[idx]
    return vec


def cosine_similarity_matrix(matrix, query_vec):
    """
    Cosine similarity between query_vec and EVERY row of matrix at
    once — same formula as always, just vectorized.
    """
    dots = matrix @ query_vec
    doc_norms = np.linalg.norm(matrix, axis=1)
    query_norm = np.linalg.norm(query_vec)
    if query_norm == 0:
        return np.zeros(matrix.shape[0])
    denom = doc_norms * query_norm
    denom[denom == 0] = 1
    return dots / denom


_tfidf_cache = {"key": None, "vocab": None, "word_index": None, "idf": None, "matrix": None}


def _get_tfidf_matrix(documents):
    cache_key = hash(tuple(documents))
    if _tfidf_cache["key"] == cache_key:
        c = _tfidf_cache
        return c["vocab"], c["word_index"], c["idf"], c["matrix"]

    tokenized_docs = [tokenize(doc) for doc in documents]
    vocab, word_index = build_vocabulary(tokenized_docs)
    idf = compute_idf_vector(tokenized_docs, vocab, word_index)
    matrix = np.array([
        document_to_tfidf_vector(tokens, vocab, word_index, idf)
        for tokens in tokenized_docs
    ])

    _tfidf_cache.update(key=cache_key, vocab=vocab, word_index=word_index, idf=idf, matrix=matrix)
    return vocab, word_index, idf, matrix


def tfidf_search(query, documents):
    """
    Returns a list of similarity scores — one per document, aligned
    with `documents` — for how relevant each is to the query.
    """
    vocab, word_index, idf, matrix = _get_tfidf_matrix(documents)
    query_vec = document_to_tfidf_vector(tokenize(query), vocab, word_index, idf)
    scores = cosine_similarity_matrix(matrix, query_vec)
    return scores.tolist()


def find_similar_documents(target_index, documents, top_n=4):
    """
    Returns the top_n documents most similar to documents[target_index],
    as (index, score) tuples, score > 0 only.
    """
    vocab, word_index, idf, matrix = _get_tfidf_matrix(documents)
    target_vec = matrix[target_index]
    scores = cosine_similarity_matrix(matrix, target_vec)
    scores[target_index] = -1

    top_indices = np.argsort(scores)[::-1][:top_n]
    return [(int(i), float(scores[i])) for i in top_indices if scores[i] > 0]


def build_user_profile_vector(liked_indices, matrix):
    """
    Averages the TF-IDF vectors of every listing a user has liked into
    one "profile vector" describing what they tend to like.
    """
    return matrix[liked_indices].mean(axis=0)


def recommend_for_user(liked_listing_ids, all_listings, documents, top_n=8):
    """
    Ranks every listing a user HASN'T liked by cosine similarity to
    their averaged taste profile.
    """
    vocab, word_index, idf, matrix = _get_tfidf_matrix(documents)

    liked_indices = [i for i, l in enumerate(all_listings) if l.id in liked_listing_ids]
    if not liked_indices:
        return []

    profile_vector = build_user_profile_vector(liked_indices, matrix)
    scores = cosine_similarity_matrix(matrix, profile_vector)
    for i in liked_indices:
        scores[i] = -1

    top_indices = np.argsort(scores)[::-1][:top_n]
    return [(int(i), float(scores[i])) for i in top_indices if scores[i] > 0]


# ──────────────────────────────────────────────────────────────────
# Fuzzy matching — pure Python, no library
# ──────────────────────────────────────────────────────────────────

def levenshtein_distance(s1, s2):
    """
    Damerau-Levenshtein distance: standard Levenshtein (insert, delete,
    substitute) plus transposition — swapping two adjacent characters
    counts as ONE edit instead of two. "form" vs "from" is one
    accidental key-swap away; plain Levenshtein scores it as distance 2
    and understates how close they actually are. This is a small
    extension over classic Levenshtein: same DP table, plus one extra
    check per cell for an adjacent transposition.
    """
    if s1 == s2:
        return 0
    if len(s1) == 0:
        return len(s2)
    if len(s2) == 0:
        return len(s1)

    len1, len2 = len(s1), len(s2)
    d = [[0] * (len2 + 1) for _ in range(len1 + 1)]
    for i in range(len1 + 1):
        d[i][0] = i
    for j in range(len2 + 1):
        d[0][j] = j

    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else 1
            d[i][j] = min(
                d[i - 1][j] + 1,      # deletion
                d[i][j - 1] + 1,      # insertion
                d[i - 1][j - 1] + cost,  # substitution
            )
            if i > 1 and j > 1 and s1[i - 1] == s2[j - 2] and s1[i - 2] == s2[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)  # transposition

    return d[len1][len2]


def fuzzy_ratio(s1, s2):
    """
    FuzzyWuzzy-style similarity ratio on a 0-100 scale:
        ratio = (sum_len - distance) / sum_len * 100
    """
    if not s1 and not s2:
        return 100.0
    sum_len = len(s1) + len(s2)
    if sum_len == 0:
        return 100.0
    distance = levenshtein_distance(s1, s2)
    return ((sum_len - distance) / sum_len) * 100


def fuzzy_best_match(word, vocabulary, threshold=75):
    """
    Finds the closest word to `word` inside `vocabulary` by fuzzy_ratio.
    Returns (best_word, score) if the best score is >= threshold,
    otherwise (None, best_score_found).
    """
    best_word = None
    best_score = 0.0

    for candidate in vocabulary:
        if candidate == word:
            return candidate, 100.0
        if abs(len(candidate) - len(word)) > max(3, len(word) // 2):
            continue
        score = fuzzy_ratio(word, candidate)
        if score > best_score:
            best_score = score
            best_word = candidate

    if best_word is not None and best_score >= threshold:
        return best_word, best_score
    return None, best_score


def fuzzy_correct_tokens(query_tokens, vocabulary, threshold=75):
    """
    Swaps any query token not found verbatim in `vocabulary` for its
    closest fuzzy match, if one scores at or above `threshold`.
    """
    corrected = []
    for token in query_tokens:
        if token in vocabulary:
            corrected.append(token)
            continue
        match, _score = fuzzy_best_match(token, vocabulary, threshold=threshold)
        corrected.append(match if match else token)
    return corrected


def smart_search(query, documents, fuzzy_threshold=75):
    """
    Typo-tolerant search: fuzzy-corrects the query against the real
    vocabulary found in listings, then runs it through tfidf_search.

    Returns (scores, corrected_tokens).
    """
    tokenized_docs = [tokenize(doc) for doc in documents]
    vocabulary = {word for tokens in tokenized_docs for word in tokens}

    query_tokens = tokenize(query)
    corrected_tokens = fuzzy_correct_tokens(query_tokens, vocabulary, threshold=fuzzy_threshold)
    corrected_query = " ".join(corrected_tokens)

    scores = tfidf_search(corrected_query, documents)
    return scores, corrected_tokens